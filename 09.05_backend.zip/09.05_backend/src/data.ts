import { IKutya } from "./kutya";

export const data:IKutya[] = [
    {
        "id": 1,
        "nev": "Mendy",
        "fajta": "keverék",
        "nem": false,
        "eletkor": 3,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/mendy20251.jpg"
    },
    {
        "id": 2,
        "nev": "Zsazsa",
        "fajta": "keverék",
        "nem": false,
        "eletkor": 11,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/zsazsa20251.jpg"
    },
    {
        "id": 3,
        "nev": "Bobi",
        "fajta": "pekingi palotakutya",
        "nem": true,
        "eletkor": 11,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/bobi20251.jpg"
    },
    {
        "id": 4,
        "nev": "Figura",
        "fajta": "mudi keverék",
        "nem": true,
        "eletkor": 1,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/figura20251.jpg"
    },
    {
        "id": 5,
        "nev": "Harcos",
        "fajta": "németjuhász keverék",
        "nem": true,
        "eletkor": 1,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/harcos20242.jpg"
    },
    {
        "id": 6,
        "nev": "Liza",
        "fajta": "rottweiler keverék",
        "nem": false,
        "eletkor": 12,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/liza20251.jpg"
    },
    {
        "id": 7,
        "nev": "Csöpi",
        "fajta": "keverék",
        "nem": true,
        "eletkor": 8,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/csopi20244.jpg"
    },
    {
        "id": 8,
        "nev": "Briós",
        "fajta": "keverék",
        "nem": false,
        "eletkor": 7,
        "kepUrl": "https://www.tappancs.hu/sites/default/files/styles/full_width_gallery/public/media/brios20245.jpg"
    }
]