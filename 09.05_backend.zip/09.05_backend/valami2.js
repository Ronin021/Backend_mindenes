"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log("Na üdv!.....");
console.log("Na üdv!.....de más");
console.log("Csá");
console.log("Csá de másmilyen csá");
//# sourceMappingURL=valami2.js.map