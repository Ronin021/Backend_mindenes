console.log("Na üdv!.....")

console.log("Na üdv!.....de más")

console.log("Csá")

console.log("Csá de másmilyen csá")